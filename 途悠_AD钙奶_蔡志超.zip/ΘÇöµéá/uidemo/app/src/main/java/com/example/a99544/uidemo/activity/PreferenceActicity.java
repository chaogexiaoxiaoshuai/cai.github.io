package com.example.a99544.uidemo.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.a99544.uidemo.R;

/*
推荐，已弃用
 */

public class PreferenceActicity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preference);
    }
}

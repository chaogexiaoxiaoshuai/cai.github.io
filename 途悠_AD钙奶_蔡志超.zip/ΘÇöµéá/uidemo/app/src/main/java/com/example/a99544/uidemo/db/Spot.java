package com.example.a99544.uidemo.db;

import org.litepal.crud.DataSupport;

/**
 * Created by 99544 on 2017/10/21.
 */

public class Spot extends DataSupport {//对应step2_选择景点
}

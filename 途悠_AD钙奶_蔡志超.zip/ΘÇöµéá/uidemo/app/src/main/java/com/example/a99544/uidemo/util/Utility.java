package com.example.a99544.uidemo.util;

import com.example.a99544.uidemo.gson.Sight;

/**
 * Created by 99544 on 2017/10/21.
 */

public class Utility {

    /**
     * 解析和处理服务器返回的数据
     */
    public static Sight handleSightResponse(String response){

        return null;

    }
}

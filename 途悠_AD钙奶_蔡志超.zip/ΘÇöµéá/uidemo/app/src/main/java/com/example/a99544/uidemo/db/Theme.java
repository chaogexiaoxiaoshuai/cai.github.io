package com.example.a99544.uidemo.db;

import org.litepal.crud.DataSupport;

/**
 * Created by 99544 on 2017/10/21.
 */

public class Theme extends DataSupport {//对应step1_选择主题
}

package com.example.a99544.uidemo.db;

import org.litepal.crud.DataSupport;

/**
 * Created by 99544 on 2017/10/21.
 */

public class Recommend extends DataSupport {//对应主界面—发现—推荐
}
